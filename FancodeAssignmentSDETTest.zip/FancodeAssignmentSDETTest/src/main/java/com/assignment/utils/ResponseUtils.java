package com.assignment.utils;

import io.restassured.response.Response;

public class ResponseUtils {
    public static <T> T[] getResponseAsArray(Response response, Class<T[]> responseType) {
        return response.getBody().as(responseType);
    }
}
